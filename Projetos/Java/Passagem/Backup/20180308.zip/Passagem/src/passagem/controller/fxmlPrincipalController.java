package passagem.controller;

import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Accordion;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TitledPane;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import passagem.model.Passagem;

public class fxmlPrincipalController implements Initializable {

    /** ************************************************************************
     FXML
     ************************************************************************ */
    @FXML
    private Label lbUser, lbDataTop;
    @FXML
    private TableView<Passagem> tabelaPassagens = new TableView<Passagem>();
    @FXML
    private TableColumn<Passagem, String> colAssunto = new TableColumn();
    @FXML
    private TableColumn<Passagem, String> colTipo = new TableColumn();
    @FXML
    private TableColumn<Passagem, String> colAutor = new TableColumn();
    @FXML
    private TableColumn<Passagem, String> colData = new TableColumn();
    @FXML
    private TableColumn<Passagem, String> colStatus = new TableColumn();
    @FXML
    private Accordion accordionTabela = new Accordion();
    @FXML
    private TitledPane tituloAcordion1 = new TitledPane();

    /** ************************************************************************
     Variáveis Locais
     ************************************************************************ */
    public fxmlPrincipalController() {
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //Passa o nome do usuário para a Label
        this.lbUser.setText("Usuário: " + System.getProperty("user.name"));
        //Passa a data e hora para o Label
        this.lbDataTop.setText(this.getHoraAtual());

        //Bind das colunas às propriedades do objeto Passagem
        //As propriedades são: assunto, autor, data e tipo
        //Criando uma fábrica de objeto a ser colocado dentro das células da coluna
        this.colAssunto.setCellFactory(ComboBoxTableCell.forTableColumn("xxxx", "yyy", "11111", "aaaaa"));

        this.colAssunto.setCellValueFactory(new PropertyValueFactory<Passagem, String>("assunto"));
        this.colAutor.setCellValueFactory(new PropertyValueFactory<Passagem, String>("autor"));
        this.colData.setCellValueFactory(new PropertyValueFactory<Passagem, String>("data"));
        this.colTipo.setCellValueFactory(new PropertyValueFactory<Passagem, String>("tipo"));

        //Instanciação dos objetos e passagem dos mesmos a um array
        ArrayList<Passagem> lista = new ArrayList<>();
        lista.add(new Passagem("assunto1", "autor1", "data1", "tipo1"));
        lista.add(new Passagem("assunto2", "autor2", "data1", "tipo1"));
        lista.add(new Passagem("assunto3", "autor3", "data2", "tipo1"));
        lista.add(new Passagem("assunto4", "autor4", "data3", "tipo2"));
        lista.add(new Passagem("assunto5", "autor5", "data3", "tipo2"));

        //Tornando a lista observável
        ObservableList<Passagem> listaDeClientes = FXCollections.observableArrayList(lista);

        //Passando a lista para a tabela
        tabelaPassagens.setItems(listaDeClientes);

        //Teste accordion - Inserindo Titleds
        for (int i = 0; i < 10; i++) {
            TitledPane tp = new TitledPane();
            tp.setText(String.valueOf(i+1));
            //Inserindo um AnchorPane como conteúdo a cada titled pane
            AnchorPane ap = new AnchorPane();
            //Inserindo um TableView dentro do AnchorPane
            TableView tv = new TableView();
            ap.getChildren().add(tv);
                //Inserindo colunas nas tabelas
                for(int j=1;j<6;j++){
                    tv.getColumns().add(new TableColumn("Coluna " + String.valueOf(j)));
                    }
            tp.setContent(ap);
            accordionTabela.getPanes().add(tp);
        }

    }

    private String getHoraAtual() {
        String horaAtual;
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yy HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        horaAtual = dtf.format(now);
        System.out.println(horaAtual);
        return horaAtual;
    }

}
