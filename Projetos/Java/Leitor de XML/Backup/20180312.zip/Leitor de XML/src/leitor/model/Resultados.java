/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leitor.model;

import java.util.ArrayList;

/**

 @author Petrobras
 */
public class Resultados {

    private static int i;
    private String nomeNode;
    private String node;

    public Resultados() {

    }

    private ArrayList array = new ArrayList();

    public ArrayList getArray() {
        return array;
    }

    public void setArray(ArrayList array) {
        this.array = array;
    }

    public String getNomeNode() {
        return nomeNode;
    }

    public void setNomeNode(String nomeNode) {
        this.nomeNode = nomeNode;
    }

    public String getNode() {
        return node;
    }

    public void setNode(String node) {
        this.node = node;
    }

}
