package leitor.model;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Xml {
    
    private ArrayList<File> listaArquivosXML = new ArrayList();
    private ArrayList<Resultados> listaResultadosName = new ArrayList();
    private ArrayList<Resultados> listaResultadosParam = new ArrayList();
    
    public ArrayList<Resultados> getListaResultados() {
        return listaResultadosName;
    }
    
    public ArrayList getListaArquivosXML() {
        return listaArquivosXML;
    }
    static int depthOfXML = 1;
    
    public Xml() throws SAXException {
        //Diretorio de origem
        //( ! ) Inserir seletor de diretório
        File pastaOrigem = new File("E:\\Adam\\Projetos\\TELAS XML");
        //Lista de arquivos no diretório
        File[] listaArquivos = pastaOrigem.listFiles();

        //Encontra os arquivos .xml
        for (File f : listaArquivos) {
            String nome = f.getName();
            //Pega a extensão do arquivo
            nome = nome.substring(nome.indexOf(".") + 1);
            if (nome.equals("xml") && !f.getName().contains("$")) {
                try {
                    System.out.println("Encontrado xml: " + f.getName());
                    this.listaArquivosXML.add(f);
                    this.dom(f);
                } catch (Exception ex) {
                    Logger.getLogger(Xml.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
    private void dom(File xml) throws SAXException, IOException {

        //Primeiro passo é carregar o XML na memória
        // Passo 1 - DocumentBuilderFactory
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        // Passo 2 - DocumentBuilder
        DocumentBuilder db;
        try {
            db = dbf.newDocumentBuilder();
            // Passo 3 - Parse (particionamentos)
            Document doc = db.parse(xml);

            //Assim que se consegue o Parse, tem-se a Interface Document.
            //Desta forma é possível caminhar pela árvore do DOM
//-----------------------------------------------------------------------------------------------------------------
            Element n0 = doc.getDocumentElement();
            System.out.println("Encontrados " + n0.getChildNodes().getLength() + " elementos após raiz");
            this.linha();
            int nivel = 0;
//Nível 0 - Nodes/Attributes
            this.buscaRaizChildren(n0);
            this.buscaAtributos(n0);
//-----------------------------------------------------------------------------------------------------------------            
//Nível 1 - Nodes/Attributes
            if (n0.hasChildNodes()) {
                nivel++;
                //A partir deste ponto pode existir Nodelists.
                NodeList n1 = n0.getChildNodes();

                //Um array de letras é montado baseado em quão profunda é a hierarquia do xml
                //A profundidade é passada pelo retorno do resultado de printNode()
                ArrayList<Integer> listaIterador = new ArrayList();
                for (int iterador = 0; iterador <= printNode(n1, 0); iterador++) {
                    listaIterador.add(iterador);
                }
                
                for (int i = 0; i < n1.getLength(); i++) {
                    Node node = (Node) n1.item(i);
                    short tipo = node.getNodeType();

                    //Tipo 1 é Element
                    if (tipo == 1) {
                        
                        Element e = (Element) n1.item(i);
                        String nodeAtual = n1.item(i).getNodeName();
                        String nomeNode = e.getAttribute("name");
                        System.out.println("Nome do resultado n1 = "
                                + nodeAtual
                                + " name = " + e.getAttribute("name"));
                        Resultados res = new Resultados();
                        res.setNomeNode(nomeNode);
                        res.setNode(nodeAtual);
                        this.listaResultadosName.add(res);
                    }
                    this.buscaNodesFilhos(n1, i, nivel);
                    this.buscaNodesAtributos(n1, i, nivel);
//-----------------------------------------------------------------------------------------------------------------  
//Nível 2 - Nodes/Attributes
                    if (n1.item(i).hasChildNodes()) {
                        nivel++;
                        NodeList n2 = n1.item(i).getChildNodes();
                        for (int j = 0; j < n2.getLength(); j++) {
                            this.buscaNodesFilhos(n2, j, nivel);
                            this.buscaNodesAtributos(n2, j, nivel);
//-----------------------------------------------------------------------------------------------------------------  
//Nível 3 - Nodes/Attributes
                            if (n2.item(j).hasChildNodes()) {
                                nivel++;
                                NodeList n3 = n2.item(j).getChildNodes();
                                for (int k = 0; k < n3.getLength(); k++) {
                                    this.buscaNodesFilhos(n3, k, nivel);
                                    this.buscaNodesAtributos(n3, k, nivel);
//----------------------------------------------------------------------------------------------------------------- 
//Nível 4 - Nodes/Attributes
                                    if (n3.item(k).hasChildNodes()) {
                                        nivel++;
                                        NodeList n4 = n3.item(k).getChildNodes();
                                        for (int l = 0; l < n4.getLength(); l++) {
                                            this.buscaNodesFilhos(n4, l, nivel);
                                            this.buscaNodesAtributos(n4, l, nivel);
//----------------------------------------------------------------------------------------------------------------- 
//Nível 5 - Nodes/Attributes
                                            if (n4.item(l).hasChildNodes()) {
                                                nivel++;
                                                NodeList n5 = n4.item(l).getChildNodes();
                                                for (int m = 0; m < n5.getLength(); m++) {
                                                    this.buscaNodesFilhos(n5, m, nivel);
                                                    this.buscaNodesAtributos(n5, m, nivel);
//----------------------------------------------------------------------------------------------------------------- 
//Nível 6 - Nodes/Attributes
                                                    if (n5.item(m).hasChildNodes()) {
                                                        nivel++;
                                                        NodeList n6 = n5.item(m).getChildNodes();
                                                        for (int n = 0; n < n6.getLength(); n++) {
                                                            this.buscaNodesFilhos(n6, n, nivel);
                                                            this.buscaNodesAtributos(n6, n, nivel);
//----------------------------------------------------------------------------------------------------------------- 
//Nível 7 - Nodes/Attributes
                                                            if (n6.item(n).hasChildNodes()) {
                                                                nivel++;
                                                                NodeList n7 = n6.item(n).getChildNodes();
                                                                for (int o = 0; o < n7.getLength(); o++) {
                                                                    this.buscaNodesFilhos(n7, o, nivel);
                                                                    this.buscaNodesAtributos(n7, o, nivel);
//----------------------------------------------------------------------------------------------------------------- 
//Nível 8 - Nodes/Attributes
                                                                    if (n7.item(o).hasChildNodes()) {
                                                                        nivel++;
                                                                        NodeList n8 = n7.item(o).getChildNodes();
                                                                        for (int p = 0; p < n7.getLength(); p++) {
                                                                            this.buscaNodesFilhos(n8, p, nivel);
                                                                            this.buscaNodesAtributos(n8, p, nivel);
//----------------------------------------------------------------------------------------------------------------- 
//Nível 8 - Nodes/Attributes
                                                                            if (n8.item(p).hasChildNodes()) {
                                                                                nivel++;
                                                                                NodeList n9 = n8.item(p).getChildNodes();
                                                                                for (int q = 0; q < n8.getLength(); p++) {
                                                                                    this.buscaNodesFilhos(n9, q, nivel);
                                                                                    this.buscaNodesAtributos(n9, q, nivel);
                                                                                }
                                                                                nivel--;
                                                                            }
                                                                        }
                                                                        nivel--;
                                                                    }
                                                                }
                                                                nivel--;
                                                            }
                                                        }
                                                        nivel--;
                                                    }
                                                }
                                                nivel--;
                                            }
                                        }
                                        nivel--;
                                    }
                                }
                                
                                nivel--;
                            }
                        }
                        nivel--;
                    }
                }
                nivel--;
                try {
                } catch (Exception e) {
                    System.err.println("Erro ao usar o printNode");
                }
            }

//------------------------------------------------------------------------------------------------------------------
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(Xml.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println("Erro");
        }
        
    }
    
    private void linha() {
        System.out.println("______________________________________________________\n");
    }
    
    private void buscaAtributos(Element raiz) {
        if (raiz.hasAttributes()) {
            NamedNodeMap atributos = raiz.getAttributes();
            for (int i = 0; i < atributos.getLength(); i++) {
                System.out.println("   ." + atributos.item(i));
            }
        }
    }
    
    private void buscaRaizChildren(Element raiz) {
        if (raiz.hasChildNodes()) {
            System.out.println("(+)" + raiz.getNodeName());
        }
    }
    
    private void buscaNodesFilhos(NodeList nl, int i, int nivel) {
        try {
            
            String espaço = "";
            for (int n = 0; n < nivel; n++) {
                espaço = espaço + "\t";
            }
            
            if (nl.item(i).hasChildNodes()) {
                
//                System.out.println(espaço + "(+)"
//                        + " " + nl.item(i).getNodeName());
            } else if (nl.item(i).getNodeName().contains("#")) {
            } else {
//            System.out.println(espaço + "(-)"
//                    + " " + nl.item(i).getNodeName());
            }
        } catch (Exception e) {
            System.err.println("Erro ao buscar Nodes");
        }
    }
    
    private void buscaNodesAtributos(NodeList n1, int i, int nivel) {
        try {
            String espaço = "";
            for (int n = 0; n < nivel; n++) {
                espaço = espaço + "\t";
            }
            
            if (n1.item(i).hasAttributes()) {
                NamedNodeMap atributos = n1.item(i).getAttributes();
                for (int j = 0; j < atributos.getLength(); j++) {
                    //System.out.println(espaço + " ." + atributos.item(j));
                }
            }
        } catch (Exception e) {
            System.err.println("Errao ao acessar atributos");
        }
    }
    
    private static int printNode(NodeList nodeList, int level) {
        level++;
        if (nodeList != null && nodeList.getLength() > 0) {
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node nodePrint = nodeList.item(i);
                if (nodePrint.getNodeType() == Node.ELEMENT_NODE) {
                    printNode(nodePrint.getChildNodes(), level);
                    if (level > depthOfXML) {
                        depthOfXML = level;
                    }
                }
            }
        }
        return depthOfXML;
        
    }
}
